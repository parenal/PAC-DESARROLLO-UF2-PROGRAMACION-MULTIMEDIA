package com.example.pac_uf2_arenalbertschipablo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)


        val adminBd = SQLiteAdministrador(this, "pokedex", null, 1)


        val btnAñadirPoke: Button = findViewById(R.id.buttonAñadirPoke)
        val editPoke: EditText = findViewById(R.id.editTextNombrePoke)
        val editNumPoke: EditText = findViewById(R.id.editTextNumPoke)

        val btnAct1: Button = findViewById(R.id.btnAct1)


        val txtPoke1: TextView = findViewById(R.id.nombrePokemon1)
        val txtNum1: TextView = findViewById(R.id.numeroPokemon1)
        val txtPoke2: TextView = findViewById(R.id.nombrePokemon2)
        val txtNum2: TextView = findViewById(R.id.numeroPokemon2)
        val txtPoke3: TextView = findViewById(R.id.nombrePokemon3)
        val txtNum3: TextView = findViewById(R.id.numeroPokemon3)
        val txtPoke4: TextView = findViewById(R.id.nombrePokemon4)
        val txtNum4: TextView = findViewById(R.id.numeroPokemon4)
        val txtPoke5: TextView = findViewById(R.id.nombrePokemon5)
        val txtNum5: TextView = findViewById(R.id.numeroPokemon5)

        btnAct1.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


        if (adminBd.existeTablaDatos()) {
            val listaPokemones = adminBd.listaPokemones()
            txtPoke1.text = listaPokemones.get(0).nombre
            txtNum1.text = listaPokemones.get(0).numpokedex.toString()
            txtPoke2.text = listaPokemones.get(1).nombre
            txtNum2.text = listaPokemones.get(1).numpokedex.toString()
            txtPoke3.text = listaPokemones.get(2).nombre
            txtNum3.text = listaPokemones.get(2).numpokedex.toString()
            txtPoke4.text = listaPokemones.get(3).nombre
            txtNum4.text = listaPokemones.get(3).numpokedex.toString()
            txtPoke5.text = listaPokemones.get(4).nombre
            txtNum5.text = listaPokemones.get(4).numpokedex.toString()
        }


        btnAñadirPoke.setOnClickListener {
            val nombrePoke = editPoke.getText().toString()
            val numPoke = Integer.parseInt(editNumPoke.getText().toString())

            if (adminBd.existePokemon(nombrePoke))
                adminBd.actualizarNumeroPokedex(nombrePoke, numPoke)
            else
                adminBd.insertarPokemon(nombrePoke, numPoke)

            //Actualizamos el top5

            val listaPokemones = adminBd.listaPokemones()
            txtPoke1.text = listaPokemones.get(0).nombre
            txtNum1.text = listaPokemones.get(0).numpokedex.toString()
            txtPoke2.text = listaPokemones.get(1).nombre
            txtNum2.text = listaPokemones.get(1).numpokedex.toString()
            txtPoke3.text = listaPokemones.get(2).nombre
            txtNum3.text = listaPokemones.get(2).numpokedex.toString()
            txtPoke4.text = listaPokemones.get(3).nombre
            txtNum4.text = listaPokemones.get(3).numpokedex.toString()
            txtPoke5.text = listaPokemones.get(4).nombre
            txtNum5.text = listaPokemones.get(4).numpokedex.toString()


            // Informamos al usuario
            Toast.makeText(
                this,
                "Numero de Pokedex de '${nombrePoke}' actualizado",
                Toast.LENGTH_SHORT
            ).show()
        }


    }
}