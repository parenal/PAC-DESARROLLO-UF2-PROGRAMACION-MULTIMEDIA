package com.example.pac_uf2_arenalbertschipablo

//Importar el reproductor, widget button y widget Toast (para mensaje emergente)

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import android.media.MediaPlayer
import android.content.Intent


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Referenciacion a los botones

        val buttonPlay : Button = findViewById(R.id.btnPlay)
        val buttonStop : Button = findViewById(R.id.btnStop)
        val buttonActivity2 : Button = findViewById(R.id.btnAct2)
        val buttonActivity3 : Button = findViewById(R.id.btnAct3)
        val buttonActivity4 : Button = findViewById(R.id.btnAct4)

        //Creacion del reproductor

        var mediaPlayer = MediaPlayer.create(this, R.raw.pokemon)

        //Asignar mensajes emergentes a los botones
        buttonPlay.setOnClickListener{
            mediaPlayer.start()
            Toast.makeText(this, "Iniciando reproduccion...", Toast.LENGTH_LONG).show()
        }

        buttonStop.setOnClickListener{
            mediaPlayer.stop()
            Toast.makeText(this, "Parando reproduccion...", Toast.LENGTH_LONG).show()
            //Al darle a parar y querer que vuelva a sonar no fuciona asi sin mas
            //Solucionado gracias a Contenido en Campus Ilerna
            mediaPlayer = MediaPlayer.create(this, R.raw.pokemon)
        }

        buttonActivity2.setOnClickListener {
            val intent = Intent(this, Activity2::class.java)
            startActivity(intent)
        }
        buttonActivity3.setOnClickListener {
            val intent = Intent(this, Activity3::class.java)
            startActivity(intent)
        }
        buttonActivity4.setOnClickListener {
            val intent = Intent(this, Activity4::class.java)
            startActivity(intent)
        }



    }
}