package com.example.pac_uf2_arenalbertschipablo

class Pokemon (val nombre : String, val numpokedex : Int) : Comparable<Pokemon>{
    override fun compareTo(otroPokemon: Pokemon): Int {
        return this.numpokedex - otroPokemon.numpokedex
    }
}