package com.example.pac_uf2_arenalbertschipablo

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory
import android.database.sqlite.SQLiteOpenHelper

class SQLiteAdministrador (context: Context, name: String, factory: CursorFactory?, version: Int) : SQLiteOpenHelper(context, name, factory, version) {


    companion object {
        const val DATABASE_NAME = "pokedex.db"
        const val TABLE_NAME = "pokemones"
        const val NOMBREPOKE = "nombre"
        const val NUMPOKE = "numpokedex" }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("create table $TABLE_NAME($NOMBREPOKE text primary key, $NUMPOKE integer)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

    }

    fun existeTablaDatos() : Boolean {
        val db=this.writableDatabase
        val res = db.rawQuery("select * from " + TABLE_NAME, null)
        return res.moveToFirst();
    }


    fun existePokemon(nombre:String) : Boolean {
        val db=this.writableDatabase
        val sql = "select * from " + TABLE_NAME + " where " + NOMBREPOKE + "='" + nombre +"'"
        val res = db.rawQuery(sql,null)
        return res.moveToFirst();
    }


    fun insertarPokemon(nombre : String, numpokedex : Int){
        val content = ContentValues()
        content.put(NOMBREPOKE, nombre)
        content.put(NUMPOKE,numpokedex)
        val db=this.writableDatabase
        db.insert(TABLE_NAME,null,content)
    }


    fun actualizarNumeroPokedex(nombre : String, numpokedex: Int) {
        val db=this.writableDatabase
        val sql="UPDATE pokemones SET numpokedex=" + numpokedex + " WHERE nombre='" + nombre + "'"
        db.execSQL(sql)
    }





    fun listaPokemones() : ArrayList<Pokemon>  {
        val db = this.writableDatabase
        val res = db.rawQuery("select * from " + TABLE_NAME + " order by numpokedex desc", null)
        val pokemones = ArrayList<Pokemon>()
        while (res.moveToNext()) {
            var pokemon = Pokemon(res.getString(0), Integer.valueOf(res.getString(1)))
            pokemones.add(pokemon)
        }
        return pokemones
    }
}